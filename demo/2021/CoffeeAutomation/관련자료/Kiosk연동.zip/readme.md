1. sudo apt-get install unixodbc-dev
2. pip install pyodbc